# Bootstrap 4 Library 教學

## 目錄
1. [設定Gulp及開發環境](#＊設定Gulp及開發環境)
2. [Template檔案介紹](#＊Template檔案介紹)
3. [★五星推薦的快捷鍵](#＊★五星推薦的快捷鍵)

## ＊設定Gulp及開發環境
1. 使用VS Code作為開發IDE  [VS Code Download](https://code.visualstudio.com/)
安裝完成後,請在Vs Code安裝兩個套件
    > 1. Sublime Text keymap
    > `可利用熱鍵加速上手VS CODE的速度`
    > 2. Preview on Web Server(可不裝)
    > `可直接在Vs Code上開啟Web Server,進行Debug`
    ##### ~~PS.本人我以上都沒裝~~

2. Clone [GoodArc Gitlab Repository](http://gitlab.goodarc.com:32769/GoodarcDev/Bootstarp4-SCSS-Master.git)

3. 開啟VS Code,載入專案
    > 選擇開啟資料夾
    > 選擇clone資料夾名稱
    > ##### 如下圖
    > ![](https://i.imgur.com/aK6meWx.png)
4. 開啟後按下Ctrl+`,開啟終端機視窗
    > 接著開始按照下列步驟,安裝Gulp環境
    
    > 1.輸入 [Node -v] 確認NodeJS
    
    > 2.輸入 [npm install gulp -g]進行全域安裝
    
    >`Mac請輸入 [sudo install gulp -g]`
    
    > 3.輸入 [npm install]將套件進行安裝,`如專案已有gulpfile.js可不執行`
    
    > 4.上述安裝完後 輸入[gulp]即可以將Template編譯執行


## ＊Template檔案介紹
####  路徑：./source/stylesheets/ 檔案名稱：goodarcbt4.scss
> 此檔案內容為bootstrap的環境建置檔(預設會載入bootstrap相關)。

### 。下列檔案皆由上述檔案引用
PS.命名規則為 _xxxx.scss但在引用時請直接忽略下引線直接引用xxxx.scss即可，這麼做的原因是因為在scss下引線檔案並不會被輸出但可以引用，這在製作元件及變數檔案時非常方便。
####  路徑：./source/stylesheets/componets 檔案名稱：_myComponets.scss
> 此檔案內容為客製化元件的部分，所有客製化元件都在此設計。


####  路徑：./source/stylesheets/helper 檔案名稱：_variables.scss
> 此檔案內為Bootstrap 4所有可動變數,預設由Bootstrap提供,
> 爾後再進行相關客製。
 
 
### 編譯注意事項
html檔案要引用的css檔案將會在編後存放於下述路徑
 
#### 路徑：./public/stylesheets
css檔名則會與 路徑：./source/stylesheets/ 的scss名稱一致 


## ＊★五星推薦的快捷鍵
1. 在Html上輸入!後按tab，可快速產生html頁面

![](https://i.imgur.com/kNqHBk9.png)

![](https://i.imgur.com/Z2s2j94.png)

2. Html Tag*數量 後按Enter，可快速產生相對應數量的Tag

![](https://i.imgur.com/WphX7XM.png)

![](https://i.imgur.com/Z3egEiA.png)


